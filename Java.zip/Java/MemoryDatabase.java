import java.io.*;
import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/*
  @author: Kowshick Srinivasan, Qingyun PU
 * @version: 1.0
 * @Assignment: course project-2
 */

/**
 * MemoryDatabase.java
 * <p>
 * Features
 * - Load CSV into an in-memory linked list
 * - Compresses the whole database for disk storage using huffman-code
 * - Build a Red-Black tree using index column for easy search of the student records
 * <p>
 * Usage
 * javac *.java
 * java MemoryDatabase
 * # REPL examples:
 * quit
 **/
public class MemoryDatabase {

    LinkedList list;  //Object of the linked list

    private static final String BASE_PATH = "D:\\Algorithms\\CourseProject-2\\Data"; // target directory

    private static final String FILENAME = "student-data.csv";  //input file name

    private static final String OUTFILE = "student-op-data" + getTimeStamp() + ".csv"; //output file name

    //Constructor based dependency injection
    public MemoryDatabase(LinkedList list) {
        this.list = list;

    }

    /**
     * Return the current timestamp in specified format
     *
     * @return timestamp
     */
    private static String getTimeStamp() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMddyyyy_HHmmss");
        return now.format(formatter);
    }



    /**
     * Method recursively read each student details from the CSV file and adds it to the end of the linked list
     *
     * @param br      : The BufferedReader object
     * @param current : Current Node/pointer of the linked list
     * @return : Completion status of the read operation
     */
    private int read(BufferedReader br, LinkedList.Node current) throws IOException {
        String l = br.readLine();  //Read each line
        if (l == null) return 0;  //When reached EOF return
        String[] line = l.split(",");  //Split the row using "," as the separator
        Student student = convertLineToStudent(line);  //Convert the String array to the student class
        return read(br, list.insert(current, student, null));   //Recursively call the function with the buffered reader object and updated last Node/Pointer
    }


    /**
     * Accepts the String array and convert it to student object
     *
     * @param line Original String array formed after comma separation of the line
     * @return Student object
     */
    private Student convertLineToStudent(String[] line) {
        return new Student(line[0], line[1].charAt(0), Integer.parseInt(line[2]), line[3].charAt(0), line[4], line[5].charAt(0),
                Integer.parseInt(line[6]), Integer.parseInt(line[7]), line[8], line[9], line[10], line[11],
                Integer.parseInt(line[12]), Integer.parseInt(line[13]), Integer.parseInt(line[14]), line[15].equals("yes"), line[16].equals("yes"), line[17].equals("yes"), line[18].equals("yes"), line[19].equals("yes"),
                line[20].equals("yes"), line[21].equals("yes"), line[22].equals("yes"), Integer.parseInt(line[23]), Integer.parseInt(line[24]), Integer.parseInt(line[25]), Integer.parseInt(line[26]),
                Integer.parseInt(line[27]), Integer.parseInt(line[28]), Integer.parseInt(line[29]), line[30].equals("yes"));

    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MemoryDatabase database = new MemoryDatabase(
                new LinkedList()  //Initialize the list object
        );
        File inputFile = new File(BASE_PATH, FILENAME);
        File outputFile = new File(BASE_PATH, OUTFILE);
        //Since we used try with resources, we won't be needing a finally block
        try (BufferedReader br = new BufferedReader(new FileReader(inputFile)); //Buffered reader to enable to the Java methods to read from the given file
             PrintWriter printWriter = new PrintWriter(new FileWriter(outputFile))) //Buffered writer to enable the Java methods to write on the given file
        {
            br.readLine();  //Skip the Header of the csv
            database.read(br, database.list.head);   //Read the student details from the file and add it to the linked list
            //TODO: Create Huffman compression
            database.createRBTree();

        } catch (Exception e) { //Global catch block to handle all the exception thrown by the program
            e.printStackTrace(System.out);  //print the exception stack trace in console
        }
    }

    /**
     * Method to create the red back tree for the given in-memory database
     */
    private void createRBTree() {
        RedBlackTree tree = new RedBlackTree();
        LinkedList.Node current = list.head;
        //Loop until the end of the linked-list
        while(current != null){
            //We use the column absence as the index, can use any int or Char columns as index for now
            //change here to do so
            tree.insert(current.student.absence, current);
            current = current.next;
        }
        //print the constructed tree
       tree.printTree();

    }



}

